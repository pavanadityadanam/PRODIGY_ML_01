# PRODIGY_ML_01

## House Price Prediction using Linear Regression

### Objective

Build a Linear Regression model to predict house prices based on square footage, number of bedrooms, and bathrooms.

### Tools Used

* Python
* Google Colab
* Pandas
* Scikit-Learn
* Matplotlib

### Workflow

1. Loaded the housing dataset.
2. Selected important features.
3. Split data into training and testing sets.
4. Trained a Linear Regression model.
5. Predicted house prices.
6. Evaluated model performance using R² Score.
7. Visualized actual vs predicted house prices.

### Results

* Dataset Size: 1460 rows, 81 columns
* R² Score: 0.6341

### Outcome

Successfully developed a Linear Regression model capable of predicting house prices using key housing features.
